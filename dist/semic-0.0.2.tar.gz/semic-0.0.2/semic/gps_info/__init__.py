from .elevation import get_elevation, get_elevation_fr
from .geoloc import get_city, select_city_postal